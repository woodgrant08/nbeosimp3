export interface Case {
  id: number;
  title: string;
  category: string;
  difficulty: "easy" | "medium" | "hard";
  chiefComplaint: string;
  patientInfo: {
    age: number;
    sex: string;
    occupation: string;
  };
  history: string;
  correctDiagnosis: string;
  correctManagement: string[];
  learningPoints: string[];
}

export interface Session {
  id: number;
  caseId: number;
  startedAt: string;
  completedAt?: string;
  questions: Array<{ question: string; answer: string; timestamp: string }>;
  testsOrdered: Array<{ test: string; result: string; timestamp: string }>;
  assessment?: string;
  plan?: string;
  score?: number;
  feedback?: string;
}

export const cases: Case[] = [
  {
    id: 1,
    title: "Sudden Vision Loss — Elderly Male",
    category: "Retinal",
    difficulty: "hard",
    chiefComplaint: "Sudden painless vision loss in the right eye",
    patientInfo: { age: 72, sex: "Male", occupation: "Retired" },
    history:
      "Patient reports waking up this morning with painless vision loss in the right eye. No prior ocular history of note. Has a history of hypertension and atrial fibrillation. On warfarin.",
    correctDiagnosis: "Central Retinal Artery Occlusion (CRAO)",
    correctManagement: [
      "Urgent referral to emergency department",
      "Lower IOP (ocular massage, anterior chamber paracentesis if indicated)",
      "Investigate for embolic source (carotid Doppler, echocardiogram)",
      "Blood work: CBC, ESR, CRP (rule out GCA)",
      "Consider hyperbaric oxygen if within treatment window",
    ],
    learningPoints: [
      "CRAO is an ocular emergency — time is retina",
      "Classic sign: cherry red spot on fundus",
      "Must rule out Giant Cell Arteritis in patients over 50",
      "Embolic workup is essential for secondary prevention",
    ],
  },
  {
    id: 2,
    title: "Red Eye with Discharge — Young Adult",
    category: "Anterior Segment",
    difficulty: "easy",
    chiefComplaint: "Red, itchy eyes with morning discharge for 5 days",
    patientInfo: { age: 24, sex: "Female", occupation: "Teacher" },
    history:
      "Patient presents with bilateral red eyes, watery discharge, and itching for 5 days. Several students in her class had similar symptoms last week. No vision change. Contact lens wearer.",
    correctDiagnosis: "Viral Conjunctivitis (Epidemic Keratoconjunctivitis)",
    correctManagement: [
      "Discontinue contact lens wear",
      "Cool compresses for comfort",
      "Artificial tears",
      "Advise strict hygiene / hand washing to prevent spread",
      "Monitor for corneal involvement (subepithelial infiltrates)",
      "Avoid corticosteroids early in course",
    ],
    learningPoints: [
      "EKC caused by adenovirus is highly contagious",
      "Subepithelial infiltrates may appear 1–2 weeks in and affect vision",
      "Do not prescribe topical antibiotics routinely for viral conjunctivitis",
      "Patient education on hygiene is critical",
    ],
  },
  {
    id: 3,
    title: "Halos Around Lights — Middle-Aged Male",
    category: "Glaucoma",
    difficulty: "medium",
    chiefComplaint: "Halos around lights and headache",
    patientInfo: { age: 55, sex: "Male", occupation: "Accountant" },
    history:
      "Patient presents with intermittent halos around lights for 3 weeks, associated with mild frontal headaches. Episodes seem to occur in the evening. No prior eye history. Family history of glaucoma.",
    correctDiagnosis: "Angle-Closure Glaucoma (sub-acute / intermittent)",
    correctManagement: [
      "Urgent IOP measurement",
      "Gonioscopy to assess angle",
      "Dilated fundus exam (disc evaluation)",
      "Visual field testing",
      "Refer for laser peripheral iridotomy (LPI)",
      "Prophylactic LPI in fellow eye",
    ],
    learningPoints: [
      "Intermittent angle closure can present subtly with halos and mild headaches",
      "Family history is a significant risk factor",
      "LPI is curative for pupillary block mechanism",
      "Always evaluate the fellow eye",
    ],
  },
  {
    id: 4,
    title: "Floaters and Flashes — Adult Female",
    category: "Retinal",
    difficulty: "medium",
    chiefComplaint: "New floaters and flashing lights in the left eye",
    patientInfo: { age: 48, sex: "Female", occupation: "Graphic Designer" },
    history:
      "Patient noticed a sudden onset of floaters and photopsia (flashes of light) in the left eye two days ago. She is highly myopic (-8.00 D). No prior retinal history.",
    correctDiagnosis: "Posterior Vitreous Detachment with possible Retinal Tear",
    correctManagement: [
      "Dilated fundus examination (indirect ophthalmoscopy)",
      "Scleral depression to examine peripheral retina",
      "If retinal tear found: laser photocoagulation or cryopexy",
      "If retinal detachment: urgent surgical referral",
      "Patient education on warning signs (curtain/shadow in vision)",
      "Follow-up in 4–6 weeks if no tear found",
    ],
    learningPoints: [
      "High myopia is a major risk factor for retinal tears and detachment",
      "PVD is common but must be distinguished from complicated PVD with tear",
      "A 'shower of floaters' may indicate vitreous hemorrhage from a torn vessel",
      "Patient education on when to return urgently is essential",
    ],
  },
  {
    id: 5,
    title: "Diabetic Patient — Routine Exam Findings",
    category: "Systemic Disease",
    difficulty: "medium",
    chiefComplaint: "Annual diabetic eye exam — no visual complaints",
    patientInfo: { age: 61, sex: "Male", occupation: "Bus Driver" },
    history:
      "Type 2 diabetic for 15 years, poorly controlled (HbA1c 9.2%). On metformin and insulin. Hypertensive. Last eye exam 2 years ago. Fundus today shows scattered dot-blot hemorrhages, microaneurysms, hard exudates near the macula bilaterally, and two areas of new vessel formation superiorly in the right eye.",
    correctDiagnosis: "Proliferative Diabetic Retinopathy (PDR) with Clinically Significant Macular Edema",
    correctManagement: [
      "Urgent referral to retinal specialist",
      "Panretinal photocoagulation (PRP) for PDR",
      "Intravitreal anti-VEGF or laser for macular edema",
      "Coordinate with PCP for glycemic and blood pressure control",
      "Advise patient he should not drive until cleared",
      "3–4 month follow-up after treatment",
    ],
    learningPoints: [
      "PDR is a vision-threatening emergency requiring urgent referral",
      "New vessels (neovascularization) indicate ischemic drive from non-perfusion",
      "Anti-VEGF agents are now first-line for center-involving DME",
      "Systemic control (glucose, BP, lipids) is integral to management",
      "Occupation (driving) has safety and legal implications",
    ],
  },
  {
    id: 6,
    title: "Child with Eye Turn — Pediatric",
    category: "Pediatrics / Binocular Vision",
    difficulty: "easy",
    chiefComplaint: "Parent notices child's left eye drifting outward",
    patientInfo: { age: 5, sex: "Male", occupation: "Kindergarten student" },
    history:
      "Mother noticed intermittent outward deviation of the left eye for about 6 months, occurring especially when the child is tired or daydreaming. The child squints in bright sunlight. No patching history. Vision has not been tested before.",
    correctDiagnosis: "Intermittent Exotropia (X(T))",
    correctManagement: [
      "Complete cycloplegic refraction",
      "Dilated fundus exam",
      "Cover test at near and distance",
      "Stereoacuity and sensory testing",
      "Assess control of deviation",
      "Management options: observation, patching, minus lens therapy, surgery based on frequency/control",
    ],
    learningPoints: [
      "X(T) is the most common childhood exodeviation",
      "Light squinting/closing one eye in bright light is a hallmark feature",
      "Monitor control carefully — surgical intervention if deteriorating",
      "Cycloplegic refraction is mandatory in all pediatric strabismus",
    ],
  },
];

// In-memory sessions store
export const sessions: Session[] = [];
let nextSessionId = 1;

export function createNewSession(caseId: number): Session {
  const session: Session = {
    id: nextSessionId++,
    caseId,
    startedAt: new Date().toISOString(),
    questions: [],
    testsOrdered: [],
  };
  sessions.push(session);
  return session;
}

// Simple test date store
export let testDate: { date: string | null } = { date: null };

// Simple AI-powered patient answers based on case
export function getPatientAnswer(caseId: number, question: string): string {
  const c = cases.find((c) => c.id === caseId);
  if (!c) return "I'm not sure what you mean.";

  const q = question.toLowerCase();

  if (q.includes("pain") || q.includes("hurt") || q.includes("ache")) {
    if (c.correctDiagnosis.includes("CRAO")) return "No, it doesn't hurt at all. It just went blank.";
    if (c.correctDiagnosis.includes("Angle-Closure")) return "Yes, I have a mild headache behind my eye.";
    return "No real pain, just discomfort.";
  }
  if (q.includes("how long") || q.includes("when did") || q.includes("start")) {
    return `It started about ${c.history.split("for ")[1]?.split(".")[0] ?? "a few days ago"}.`;
  }
  if (q.includes("both eyes") || q.includes("which eye") || q.includes("one eye")) {
    return c.history.includes("bilateral") ? "Both eyes, actually." : "Just the one eye.";
  }
  if (q.includes("vision") || q.includes("see") || q.includes("blurry")) {
    return `My vision changed — ${c.chiefComplaint.toLowerCase()}.`;
  }
  if (q.includes("medic") || q.includes("drug") || q.includes("take anything")) {
    return c.history.includes("warfarin") ? "Yes, I'm on warfarin and blood pressure medication." :
           c.history.includes("metformin") ? "I take metformin and insulin for my diabetes." :
           "I'm not on any regular medications.";
  }
  if (q.includes("family") || q.includes("history")) {
    return c.history.includes("Family history") ? "Yes, there's some relevant family history." : "Not that I know of.";
  }
  return `${c.patientInfo.age}-year-old ${c.patientInfo.sex.toLowerCase()} here. ` +
    `I came in because ${c.chiefComplaint.toLowerCase()}. Is there anything specific you'd like to know?`;
}

export function scoreSubmission(
  session: Session,
  assessment: string,
  plan: string
): { score: number; feedback: string } {
  const c = cases.find((c) => c.id === session.caseId);
  if (!c) return { score: 0, feedback: "Case not found." };

  let score = 0;
  const feedbackParts: string[] = [];

  // Check diagnosis
  const diagnosisKeywords = c.correctDiagnosis.toLowerCase().split(/[\s,()\/]+/).filter(w => w.length > 3);
  const assessmentLower = assessment.toLowerCase();
  const diagMatches = diagnosisKeywords.filter(k => assessmentLower.includes(k)).length;
  const diagScore = Math.min(40, Math.round((diagMatches / diagnosisKeywords.length) * 40));
  score += diagScore;

  if (diagScore >= 30) {
    feedbackParts.push(`✅ Good diagnosis: Your assessment correctly identified key features of ${c.correctDiagnosis}.`);
  } else if (diagScore >= 15) {
    feedbackParts.push(`⚠️ Partial diagnosis: You identified some features but missed key aspects of ${c.correctDiagnosis}.`);
  } else {
    feedbackParts.push(`❌ Diagnosis missed: The correct diagnosis was ${c.correctDiagnosis}.`);
  }

  // Check management
  const planLower = plan.toLowerCase();
  const mgmtMatches = c.correctManagement.filter(m => {
    const keywords = m.toLowerCase().split(/[\s,()\/]+/).filter(w => w.length > 3);
    return keywords.some(k => planLower.includes(k));
  });
  const mgmtScore = Math.min(60, Math.round((mgmtMatches.length / c.correctManagement.length) * 60));
  score += mgmtScore;

  if (mgmtMatches.length >= c.correctManagement.length * 0.7) {
    feedbackParts.push(`✅ Management plan: Excellent — covered ${mgmtMatches.length} of ${c.correctManagement.length} key management steps.`);
  } else if (mgmtMatches.length >= c.correctManagement.length * 0.4) {
    feedbackParts.push(`⚠️ Management plan: Partial — covered ${mgmtMatches.length} of ${c.correctManagement.length} key steps. Missing: ${c.correctManagement.filter(m => !mgmtMatches.includes(m)).slice(0, 2).join("; ")}.`);
  } else {
    feedbackParts.push(`❌ Management plan: Incomplete — only covered ${mgmtMatches.length} of ${c.correctManagement.length} key steps.`);
  }

  feedbackParts.push(`\n📚 Key Learning Points:\n${c.learningPoints.map(p => `• ${p}`).join("\n")}`);

  return { score, feedback: feedbackParts.join("\n\n") };
}
