import { Router } from "express";
import { sessions, createNewSession, scoreSubmission } from "../data.js";

export const sessionsRouter = Router();

// Create session
sessionsRouter.post("/", (req, res) => {
  const { caseId } = req.body;
  if (!caseId) return res.status(400).json({ error: "caseId required" });
  const session = createNewSession(Number(caseId));
  res.status(201).json(session);
});

// Get session
sessionsRouter.get("/:id", (req, res) => {
  const session = sessions.find(s => s.id === Number(req.params.id));
  if (!session) return res.status(404).json({ error: "Session not found" });
  res.json(session);
});

// Submit session
sessionsRouter.post("/:id/submit", (req, res) => {
  const session = sessions.find(s => s.id === Number(req.params.id));
  if (!session) return res.status(404).json({ error: "Session not found" });
  if (session.completedAt) return res.status(400).json({ error: "Session already submitted" });

  const { assessment, plan } = req.body;
  if (!assessment || !plan) return res.status(400).json({ error: "assessment and plan required" });

  session.assessment = assessment;
  session.plan = plan;
  session.completedAt = new Date().toISOString();

  const { score, feedback } = scoreSubmission(session, assessment, plan);
  session.score = score;
  session.feedback = feedback;

  res.json({ sessionId: session.id, score, feedback });
});

// Log a question asked to patient
sessionsRouter.post("/:id/questions", (req, res) => {
  const session = sessions.find(s => s.id === Number(req.params.id));
  if (!session) return res.status(404).json({ error: "Session not found" });
  const { question, answer } = req.body;
  session.questions.push({ question, answer, timestamp: new Date().toISOString() });
  res.json(session);
});

// Log a test ordered
sessionsRouter.post("/:id/tests", (req, res) => {
  const session = sessions.find(s => s.id === Number(req.params.id));
  if (!session) return res.status(404).json({ error: "Session not found" });
  const { test, result } = req.body;
  session.testsOrdered.push({ test, result, timestamp: new Date().toISOString() });
  res.json(session);
});
