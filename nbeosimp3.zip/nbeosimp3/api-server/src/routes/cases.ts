import { Router } from "express";
import { cases, getPatientAnswer } from "../data.js";

export const casesRouter = Router();

// List all cases
casesRouter.get("/", (req, res) => {
  const { category, difficulty } = req.query;
  let filtered = cases.map(({ id, title, category, difficulty, chiefComplaint, patientInfo }) => ({
    id, title, category, difficulty, chiefComplaint, patientInfo,
  }));
  if (category) filtered = filtered.filter(c => c.category === category);
  if (difficulty) filtered = filtered.filter(c => c.difficulty === difficulty);
  res.json(filtered);
});

// Get single case
casesRouter.get("/:id", (req, res) => {
  const c = cases.find(c => c.id === Number(req.params.id));
  if (!c) return res.status(404).json({ error: "Case not found" });
  // Don't send the answer in the case details
  const { correctDiagnosis, correctManagement, learningPoints, ...caseData } = c;
  res.json(caseData);
});

// Ask patient a question
casesRouter.post("/:id/ask", (req, res) => {
  const id = Number(req.params.id);
  const { question } = req.body;
  if (!question) return res.status(400).json({ error: "Question is required" });

  const answer = getPatientAnswer(id, question);
  res.json({ answer });
});

// Ancillary tests
casesRouter.post("/:id/ancillary-tests", (req, res) => {
  const id = Number(req.params.id);
  const c = cases.find(c => c.id === id);
  if (!c) return res.status(404).json({ error: "Case not found" });

  const { tests } = req.body as { tests: string[] };
  if (!tests?.length) return res.status(400).json({ error: "Tests array required" });

  const results = tests.map(test => {
    const t = test.toLowerCase();
    // Return clinically appropriate mock results based on diagnosis
    if (c.correctDiagnosis.includes("CRAO")) {
      if (t.includes("va") || t.includes("visual acuity")) return { test, result: "OD: Count fingers at 2 feet. OS: 20/20." };
      if (t.includes("iop") || t.includes("pressure")) return { test, result: "OD: 18 mmHg. OS: 16 mmHg." };
      if (t.includes("fundus") || t.includes("dilated")) return { test, result: "OD: Pale, edematous retina with cherry red spot at fovea. Attenuated arterioles. OS: Normal." };
      if (t.includes("esr") || t.includes("crp")) return { test, result: "ESR: 42 mm/hr (elevated). CRP: 3.1 mg/L (mildly elevated)." };
    }
    if (c.correctDiagnosis.includes("Conjunctivitis")) {
      if (t.includes("va") || t.includes("visual acuity")) return { test, result: "OD: 20/20. OS: 20/20." };
      if (t.includes("slit lamp")) return { test, result: "Papillary and follicular reaction of tarsal conjunctiva OU. Mild corneal punctate staining." };
    }
    if (c.correctDiagnosis.includes("Glaucoma") || t.includes("iop")) {
      if (t.includes("iop") || t.includes("pressure")) return { test, result: "OD: 26 mmHg. OS: 24 mmHg. (Elevated)" };
      if (t.includes("goni")) return { test, result: "OD & OS: Narrow angle, Shaffer Grade I–II. Appositional closure in superior angle." };
      if (t.includes("visual field") || t.includes("hvf")) return { test, result: "OD: Mild superior nasal step. OS: Normal." };
      if (t.includes("oct") || t.includes("nerve fiber")) return { test, result: "OD: RNFL thinning superior arcade. OS: Within normal limits." };
    }
    if (c.correctDiagnosis.includes("Vitreous") || c.correctDiagnosis.includes("Retinal Tear")) {
      if (t.includes("fundus") || t.includes("dilated")) return { test, result: "Left eye: PVD present. One horseshoe tear at 11 o'clock in the periphery. No subretinal fluid." };
      if (t.includes("b-scan") || t.includes("ultrasound")) return { test, result: "Left eye: Posterior vitreous detachment confirmed. No retinal detachment." };
    }
    if (c.correctDiagnosis.includes("Diabetic")) {
      if (t.includes("fundus") || t.includes("dilated")) return { test, result: "OD: NVD present, dot-blot hemorrhages, hard exudates near macula. OS: Non-proliferative changes, dot-blot hemorrhages, hard exudates." };
      if (t.includes("oct") || t.includes("macula")) return { test, result: "OU: Center-involving diabetic macular edema. CRT OD: 412 µm. CRT OS: 388 µm." };
      if (t.includes("fa") || t.includes("fluorescein")) return { test, result: "OD: Large areas of retinal non-perfusion, leaking NVD. OS: Areas of non-perfusion, microaneurysm leakage." };
      if (t.includes("hba1c") || t.includes("blood")) return { test, result: "HbA1c: 9.2%. Blood pressure: 158/94 mmHg." };
    }
    // Generic results
    if (t.includes("va") || t.includes("visual acuity")) return { test, result: "OD: 20/40. OS: 20/25." };
    if (t.includes("iop")) return { test, result: "OD: 15 mmHg. OS: 14 mmHg." };
    if (t.includes("fundus") || t.includes("dilated")) return { test, result: "Discs healthy. C/D 0.4 OU. Macula flat. Vessels normal caliber." };
    return { test, result: "Results pending / not applicable for this case." };
  });

  res.json({ results });
});
