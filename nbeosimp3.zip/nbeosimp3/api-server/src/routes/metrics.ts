import { Router } from "express";
import { sessions, cases } from "../data.js";

export const metricsRouter = Router();

metricsRouter.get("/", (_req, res) => {
  const completed = sessions.filter(s => s.completedAt && s.score !== undefined);
  const totalSessions = completed.length;
  const avgScore = totalSessions > 0
    ? Math.round(completed.reduce((sum, s) => sum + (s.score ?? 0), 0) / totalSessions)
    : 0;

  const byCategory: Record<string, { count: number; totalScore: number }> = {};
  completed.forEach(s => {
    const c = cases.find(c => c.id === s.caseId);
    if (!c) return;
    if (!byCategory[c.category]) byCategory[c.category] = { count: 0, totalScore: 0 };
    byCategory[c.category].count++;
    byCategory[c.category].totalScore += s.score ?? 0;
  });

  const categoryMetrics = Object.entries(byCategory).map(([category, data]) => ({
    category,
    casesAttempted: data.count,
    avgScore: Math.round(data.totalScore / data.count),
  }));

  const recentSessions = completed
    .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime())
    .slice(0, 10)
    .map(s => {
      const c = cases.find(c => c.id === s.caseId);
      return {
        sessionId: s.id,
        caseTitle: c?.title ?? "Unknown",
        category: c?.category ?? "Unknown",
        score: s.score,
        completedAt: s.completedAt,
      };
    });

  res.json({
    totalSessionsCompleted: totalSessions,
    averageScore: avgScore,
    categoryMetrics,
    recentSessions,
  });
});
