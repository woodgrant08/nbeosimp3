import { Router } from "express";
import { testDate } from "../data.js";

export const testDateRouter = Router();

testDateRouter.get("/", (_req, res) => {
  res.json(testDate);
});

testDateRouter.put("/", (req, res) => {
  const { date } = req.body;
  testDate.date = date ?? null;
  res.json(testDate);
});
