import express from "express";
import cors from "cors";
import { casesRouter } from "./routes/cases.js";
import { sessionsRouter } from "./routes/sessions.js";
import { metricsRouter } from "./routes/metrics.js";
import { testDateRouter } from "./routes/test-date.js";

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Health check
app.get("/api/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

// Routes
app.use("/api/cases", casesRouter);
app.use("/api/sessions", sessionsRouter);
app.use("/api/metrics", metricsRouter);
app.use("/api/test-date", testDateRouter);

app.listen(PORT, () => {
  console.log(`API server running on http://localhost:${PORT}`);
});
