# NBEO Part 3 Simulator

An interactive clinical case simulator for optometry board exam preparation (NBEO Part 3).

## Features

- 🏥 **Clinical Cases** — Real-world optometry scenarios across multiple categories
- 💬 **Patient Interview** — Ask the simulated patient history questions
- 🔬 **Order Tests** — Request ancillary tests and get clinically relevant results
- 📋 **Assessment & Plan** — Submit your diagnosis and management plan
- 📊 **Scoring & Feedback** — Receive a score and detailed learning points
- 📈 **Metrics Dashboard** — Track progress across sessions and categories
- 📅 **Exam Countdown** — Set your exam date and track days remaining

## Project Structure

```
nbeo-exam-prep/
├── api-server/        # Express API backend (TypeScript)
│   └── src/
│       ├── index.ts
│       ├── data.ts    # Case data & scoring logic
│       └── routes/
│           ├── cases.ts
│           ├── sessions.ts
│           ├── metrics.ts
│           └── test-date.ts
└── nbeo-sim/          # React + Vite frontend (TypeScript + Tailwind)
    └── src/
        ├── App.tsx
        ├── api/client.ts
        ├── components/
        │   ├── Layout.tsx
        │   └── ui.tsx
        └── pages/
            ├── home.tsx
            ├── exam.tsx
            ├── simulation.tsx
            ├── results.tsx
            ├── metrics.tsx
            └── not-found.tsx
```

## Getting Started

### Prerequisites
- Node.js 18+
- npm 9+

### Install dependencies

```bash
npm install
cd api-server && npm install
cd ../nbeo-sim && npm install
```

### Run in development

In two terminals:

**Terminal 1 — API server:**
```bash
cd api-server
npm run dev
```

**Terminal 2 — Frontend:**
```bash
cd nbeo-sim
npm run dev
```

Then open [http://localhost:5173](http://localhost:5173).

> The frontend proxies `/api` requests to `http://localhost:3001` via Vite's dev server.

### Build for production

```bash
cd nbeo-sim
npm run build
```

## Case Categories

- Retinal
- Anterior Segment
- Glaucoma
- Systemic Disease (Diabetic Eye)
- Pediatrics / Binocular Vision

## Adding Cases

Edit `api-server/src/data.ts` and add a new entry to the `cases` array. Each case includes:

- Chief complaint, patient demographics, history
- Correct diagnosis and management steps
- Learning points for post-submission feedback

## Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS |
| State | TanStack Query v5 |
| Routing | React Router v6 |
| Backend | Express 4, TypeScript, tsx |
| Icons | Lucide React |

---

*For educational use only. Not a substitute for clinical training.*
