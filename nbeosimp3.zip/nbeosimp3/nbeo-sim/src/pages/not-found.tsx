import { Link } from "react-router-dom";
import { Eye } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <Eye className="w-16 h-16 text-slate-300 mb-6" />
      <h1 className="text-4xl font-bold text-slate-800 mb-2">404</h1>
      <p className="text-slate-500 mb-8">Page not found. This route doesn't exist.</p>
      <Link
        to="/"
        className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors"
      >
        Go Home
      </Link>
    </div>
  );
}
