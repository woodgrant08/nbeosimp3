import { useState } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { MessageSquare, FlaskConical, ClipboardList, ChevronRight, Send, Plus, X } from "lucide-react";
import {
  useGetCase,
  useAskPatient,
  useRequestTests,
  useSubmitSession,
} from "../api/client";
import { Card, Button, Spinner, DifficultyBadge } from "../components/ui";

type Tab = "history" | "tests" | "submit";

export default function Simulation() {
  const { caseId } = useParams<{ caseId: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const sessionId = Number(searchParams.get("session"));

  const { data: caseData, isLoading } = useGetCase(Number(caseId));
  const askPatient = useAskPatient(Number(caseId));
  const requestTests = useRequestTests(Number(caseId));
  const submitSession = useSubmitSession(sessionId);

  const [tab, setTab] = useState<Tab>("history");
  const [question, setQuestion] = useState("");
  const [conversation, setConversation] = useState<Array<{ q: string; a: string }>>([]);
  const [testInput, setTestInput] = useState("");
  const [pendingTests, setPendingTests] = useState<string[]>([]);
  const [testResults, setTestResults] = useState<Array<{ test: string; result: string }>>([]);
  const [assessment, setAssessment] = useState("");
  const [plan, setPlan] = useState("");

  const handleAsk = () => {
    if (!question.trim()) return;
    const q = question.trim();
    setQuestion("");
    askPatient.mutate(q, {
      onSuccess: (data) => {
        setConversation((prev) => [...prev, { q, a: data.answer }]);
      },
    });
  };

  const handleAddTest = () => {
    if (!testInput.trim()) return;
    setPendingTests((prev) => [...prev, testInput.trim()]);
    setTestInput("");
  };

  const handleRunTests = () => {
    if (!pendingTests.length) return;
    requestTests.mutate(pendingTests, {
      onSuccess: (data) => {
        setTestResults((prev) => [...prev, ...data.results]);
        setPendingTests([]);
      },
    });
  };

  const handleSubmit = () => {
    if (!assessment.trim() || !plan.trim()) return;
    submitSession.mutate(
      { assessment, plan },
      {
        onSuccess: (result) => {
          sessionStorage.setItem(`result_${result.sessionId}`, JSON.stringify(result));
          navigate(`/results/${result.sessionId}`);
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Spinner className="w-8 h-8" />
      </div>
    );
  }

  if (!caseData) {
    return <div className="text-center py-16 text-slate-500">Case not found.</div>;
  }

  return (
    <div className="space-y-6">
      {/* Case header */}
      <Card className="p-5">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                {caseData.category}
              </span>
              <DifficultyBadge difficulty={caseData.difficulty} />
            </div>
            <h1 className="text-xl font-bold text-slate-800">{caseData.title}</h1>
            <p className="text-slate-500 text-sm mt-1">
              <span className="font-medium text-slate-700">
                {caseData.patientInfo.age}yo {caseData.patientInfo.sex},{" "}
                {caseData.patientInfo.occupation}
              </span>{" "}
              — {caseData.chiefComplaint}
            </p>
          </div>
        </div>

        {/* History */}
        <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg text-sm text-slate-700 leading-relaxed">
          <span className="font-semibold text-amber-800 block mb-1">Patient History</span>
          {caseData.history}
        </div>
      </Card>

      {/* Tab nav */}
      <div className="flex border-b border-slate-200 gap-1">
        {(
          [
            { id: "history", label: "Interview Patient", icon: <MessageSquare className="w-4 h-4" /> },
            { id: "tests", label: "Order Tests", icon: <FlaskConical className="w-4 h-4" /> },
            { id: "submit", label: "Assessment & Plan", icon: <ClipboardList className="w-4 h-4" /> },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px ${
              tab === t.id
                ? "border-blue-600 text-blue-700"
                : "border-transparent text-slate-500 hover:text-slate-700"
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab: Interview */}
      {tab === "history" && (
        <div className="space-y-4">
          <Card className="p-4 space-y-4 min-h-[300px]">
            {conversation.length === 0 && (
              <p className="text-slate-400 text-sm text-center py-8">
                Ask the patient questions to gather history. Type below to start.
              </p>
            )}
            {conversation.map((item, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-end">
                  <div className="bg-blue-600 text-white rounded-2xl rounded-tr-sm px-4 py-2 text-sm max-w-[80%]">
                    {item.q}
                  </div>
                </div>
                <div className="flex justify-start">
                  <div className="bg-slate-100 text-slate-800 rounded-2xl rounded-tl-sm px-4 py-2 text-sm max-w-[80%]">
                    {item.a}
                  </div>
                </div>
              </div>
            ))}
            {askPatient.isPending && (
              <div className="flex justify-start">
                <div className="bg-slate-100 px-4 py-2 rounded-2xl">
                  <Spinner />
                </div>
              </div>
            )}
          </Card>

          <div className="flex gap-2">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAsk()}
              placeholder="Ask the patient a question…"
              className="flex-1 border border-slate-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Button onClick={handleAsk} disabled={!question.trim() || askPatient.isPending}>
              <Send className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex justify-end">
            <Button variant="secondary" onClick={() => setTab("tests")}>
              Next: Order Tests <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Tab: Tests */}
      {tab === "tests" && (
        <div className="space-y-4">
          <p className="text-sm text-slate-500">
            Order ancillary tests such as visual acuity, IOP, slit lamp, fundus exam, OCT, visual
            fields, etc.
          </p>

          <div className="flex gap-2">
            <input
              type="text"
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddTest()}
              placeholder="e.g. Visual acuity, IOP, Dilated fundus exam…"
              className="flex-1 border border-slate-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Button variant="secondary" onClick={handleAddTest} disabled={!testInput.trim()}>
              <Plus className="w-4 h-4" /> Add
            </Button>
          </div>

          {pendingTests.length > 0 && (
            <Card className="p-4">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
                Pending Tests
              </p>
              <div className="flex flex-wrap gap-2 mb-3">
                {pendingTests.map((t, i) => (
                  <span
                    key={i}
                    className="flex items-center gap-1.5 bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm"
                  >
                    {t}
                    <button onClick={() => setPendingTests((p) => p.filter((_, j) => j !== i))}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
              <Button onClick={handleRunTests} disabled={requestTests.isPending}>
                {requestTests.isPending ? <Spinner /> : "Run Tests"}
              </Button>
            </Card>
          )}

          {testResults.length > 0 && (
            <Card className="p-4">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                Results
              </p>
              <div className="space-y-3">
                {testResults.map((r, i) => (
                  <div key={i} className="border-b border-slate-100 pb-2 last:border-0 last:pb-0">
                    <div className="text-xs font-semibold text-slate-600 mb-0.5">{r.test}</div>
                    <div className="text-sm text-slate-800">{r.result}</div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <div className="flex justify-between">
            <Button variant="secondary" onClick={() => setTab("history")}>
              ← Back
            </Button>
            <Button variant="secondary" onClick={() => setTab("submit")}>
              Next: Assessment & Plan <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Tab: Submit */}
      {tab === "submit" && (
        <div className="space-y-4">
          <p className="text-sm text-slate-500">
            Write your assessment (diagnosis) and management plan based on your findings.
          </p>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              Assessment (Diagnosis)
            </label>
            <textarea
              value={assessment}
              onChange={(e) => setAssessment(e.target.value)}
              rows={4}
              placeholder="Write your differential diagnosis and primary diagnosis…"
              className="w-full border border-slate-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              Plan (Management)
            </label>
            <textarea
              value={plan}
              onChange={(e) => setPlan(e.target.value)}
              rows={6}
              placeholder="Outline your management plan including investigations, treatment, referrals, follow-up…"
              className="w-full border border-slate-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>

          <div className="flex justify-between">
            <Button variant="secondary" onClick={() => setTab("tests")}>
              ← Back
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!assessment.trim() || !plan.trim() || submitSession.isPending}
              className="px-6"
            >
              {submitSession.isPending ? <Spinner /> : "Submit & Get Feedback"}
            </Button>
          </div>

          {submitSession.isError && (
            <p className="text-sm text-red-500 text-center">{submitSession.error.message}</p>
          )}
        </div>
      )}
    </div>
  );
}
