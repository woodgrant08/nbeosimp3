import { useParams, Link, useNavigate } from "react-router-dom";
import { CheckCircle, BookOpen, RotateCcw, Home } from "lucide-react";
import { useGetSession } from "../api/client";
import { Card, Button, ScoreRing, Spinner } from "../components/ui";

export default function Results() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const id = Number(sessionId);

  // Try sessionStorage first for immediate display (set right after submission)
  const cached = sessionStorage.getItem(`result_${id}`);
  const cachedResult = cached ? JSON.parse(cached) : null;

  const { data: session, isLoading } = useGetSession(id);

  const score = cachedResult?.score ?? session?.score;
  const feedback = cachedResult?.feedback ?? session?.feedback;

  if (isLoading && !cachedResult) {
    return (
      <div className="flex items-center justify-center py-24">
        <Spinner className="w-8 h-8" />
      </div>
    );
  }

  if (score === undefined) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-500 mb-4">Results not found.</p>
        <Link to="/exam">
          <Button>Back to Cases</Button>
        </Link>
      </div>
    );
  }

  const grade =
    score >= 80 ? { label: "Excellent", color: "text-green-600" } :
    score >= 65 ? { label: "Good", color: "text-blue-600" } :
    score >= 50 ? { label: "Fair", color: "text-yellow-600" } :
    { label: "Needs Review", color: "text-red-600" };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Score card */}
      <Card className="p-8 text-center">
        <div className="flex flex-col items-center gap-2">
          <CheckCircle className="w-8 h-8 text-green-500 mb-2" />
          <h1 className="text-2xl font-bold text-slate-800">Case Complete!</h1>
          <p className="text-slate-500 text-sm">Here's how you did</p>
        </div>

        <div className="flex flex-col items-center gap-2 my-8">
          <ScoreRing score={score} />
          <div className={`text-xl font-bold ${grade.color}`}>{grade.label}</div>
          <div className="text-slate-500 text-sm">{score} out of 100 points</div>
        </div>

        <div className="flex justify-center gap-3 flex-wrap">
          <Button onClick={() => navigate("/exam")}>
            <BookOpen className="w-4 h-4" />
            Try Another Case
          </Button>
          <Button variant="secondary" onClick={() => navigate("/")}>
            <Home className="w-4 h-4" />
            Home
          </Button>
        </div>
      </Card>

      {/* Feedback */}
      {feedback && (
        <Card className="p-6">
          <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            Detailed Feedback
          </h2>
          <div className="text-sm text-slate-700 space-y-3 whitespace-pre-line leading-relaxed">
            {feedback}
          </div>
        </Card>
      )}

      {/* Submitted answers */}
      {session?.assessment && (
        <Card className="p-6">
          <h2 className="font-semibold text-slate-800 mb-4">Your Submission</h2>
          <div className="space-y-4">
            <div>
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">
                Assessment
              </div>
              <div className="text-sm text-slate-700 bg-slate-50 rounded-lg p-3">
                {session.assessment}
              </div>
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">
                Plan
              </div>
              <div className="text-sm text-slate-700 bg-slate-50 rounded-lg p-3">
                {session.plan}
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Questions asked */}
      {session?.questions && session.questions.length > 0 && (
        <Card className="p-6">
          <h2 className="font-semibold text-slate-800 mb-4">
            History Questions ({session.questions.length})
          </h2>
          <div className="space-y-2">
            {session.questions.map((q, i) => (
              <div key={i} className="text-sm border-b border-slate-100 pb-2 last:border-0">
                <span className="font-medium text-blue-700">Q: </span>
                <span className="text-slate-700">{q.question}</span>
                <br />
                <span className="font-medium text-slate-500">A: </span>
                <span className="text-slate-600">{q.answer}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
