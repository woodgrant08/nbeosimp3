import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { BookOpen, ChevronRight, Filter, User } from "lucide-react";
import { useListCases, useCreateSession } from "../api/client";
import { Card, DifficultyBadge, Button, Spinner, EmptyState } from "../components/ui";

const CATEGORIES = ["All", "Retinal", "Anterior Segment", "Glaucoma", "Systemic Disease", "Pediatrics / Binocular Vision"];
const DIFFICULTIES = ["All", "easy", "medium", "hard"];

export default function Exam() {
  const navigate = useNavigate();
  const [category, setCategory] = useState("All");
  const [difficulty, setDifficulty] = useState("All");

  const { data: cases, isLoading, error } = useListCases({
    category: category !== "All" ? category : undefined,
    difficulty: difficulty !== "All" ? difficulty : undefined,
  });

  const createSession = useCreateSession();

  const handleStart = (caseId: number) => {
    createSession.mutate(caseId, {
      onSuccess: (session) => {
        navigate(`/simulation/${caseId}?session=${session.id}`);
      },
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Clinical Cases</h1>
        <p className="text-slate-500 text-sm mt-1">
          Select a case to begin your simulated patient encounter.
        </p>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Filter className="w-4 h-4" />
            <span className="font-medium">Filter:</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                  category === c
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap gap-2">
            {DIFFICULTIES.map((d) => (
              <button
                key={d}
                onClick={() => setDifficulty(d)}
                className={`px-3 py-1 rounded-full text-xs font-medium capitalize transition-colors ${
                  difficulty === d
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {/* Cases list */}
      {isLoading && (
        <div className="flex justify-center py-16">
          <Spinner className="w-8 h-8" />
        </div>
      )}

      {error && (
        <Card className="p-8 text-center text-red-500">
          Failed to load cases. Make sure the API server is running.
        </Card>
      )}

      {cases && cases.length === 0 && (
        <EmptyState
          icon={<BookOpen className="w-16 h-16" />}
          title="No cases found"
          description="Try adjusting your filters."
        />
      )}

      {cases && cases.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {cases.map((c) => (
            <Card
              key={c.id}
              className="p-5 hover:shadow-md transition-shadow cursor-pointer group"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                      {c.category}
                    </span>
                    <DifficultyBadge difficulty={c.difficulty} />
                  </div>
                  <h3 className="font-semibold text-slate-800 text-base leading-snug">
                    {c.title}
                  </h3>
                  <p className="text-sm text-slate-500 mt-1 line-clamp-2">
                    {c.chiefComplaint}
                  </p>
                  <div className="flex items-center gap-1.5 mt-3 text-xs text-slate-400">
                    <User className="w-3.5 h-3.5" />
                    {c.patientInfo.age}yo {c.patientInfo.sex} · {c.patientInfo.occupation}
                  </div>
                </div>

                <Button
                  onClick={() => handleStart(c.id)}
                  disabled={createSession.isPending}
                  className="flex-shrink-0"
                >
                  {createSession.isPending ? (
                    <Spinner />
                  ) : (
                    <>Start <ChevronRight className="w-4 h-4" /></>
                  )}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
