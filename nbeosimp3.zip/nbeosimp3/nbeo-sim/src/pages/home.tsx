import { useState } from "react";
import { Link } from "react-router-dom";
import { Eye, BookOpen, BarChart2, Calendar, CheckCircle, Clock, Target } from "lucide-react";
import { useGetMetrics, useGetTestDate, useSetTestDate } from "../api/client";
import { Card, Button, ScoreRing } from "../components/ui";

export default function Home() {
  const { data: metrics } = useGetMetrics();
  const { data: testDateData } = useGetTestDate();
  const setTestDate = useSetTestDate();
  const [editingDate, setEditingDate] = useState(false);
  const [dateInput, setDateInput] = useState("");

  const daysUntilExam = testDateData?.date
    ? Math.ceil(
        (new Date(testDateData.date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      )
    : null;

  const handleSaveDate = () => {
    setTestDate.mutate(dateInput || null, { onSuccess: () => setEditingDate(false) });
  };

  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="bg-gradient-to-br from-blue-900 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-3 mb-4">
          <Eye className="w-10 h-10 text-blue-300" />
          <div>
            <h1 className="text-3xl font-bold">NBEO Part 3 Simulator</h1>
            <p className="text-blue-200 mt-0.5">
              Interactive clinical case practice for optometry board exams
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-3 mt-6">
          <Link to="/exam">
            <Button className="bg-white text-blue-900 hover:bg-blue-50 border-0 font-semibold px-6">
              <BookOpen className="w-4 h-4" />
              Start a Case
            </Button>
          </Link>
          <Link to="/metrics">
            <Button variant="ghost" className="text-white hover:bg-blue-800 border border-blue-500">
              <BarChart2 className="w-4 h-4" />
              View Progress
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats row */}
      {metrics && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatCard
            icon={<CheckCircle className="w-5 h-5 text-green-500" />}
            label="Cases Completed"
            value={String(metrics.totalSessionsCompleted)}
          />
          <StatCard
            icon={<Target className="w-5 h-5 text-blue-500" />}
            label="Average Score"
            value={metrics.totalSessionsCompleted > 0 ? `${metrics.averageScore}%` : "—"}
          />
          <StatCard
            icon={<Clock className="w-5 h-5 text-purple-500" />}
            label="Categories Practiced"
            value={String(metrics.categoryMetrics.length)}
          />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Exam countdown */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-blue-600" />
            <h2 className="font-semibold text-slate-800">Exam Countdown</h2>
          </div>

          {testDateData?.date && !editingDate ? (
            <div className="text-center py-4">
              <div className="text-5xl font-bold text-blue-700 mb-1">
                {daysUntilExam !== null && daysUntilExam >= 0 ? daysUntilExam : "—"}
              </div>
              <div className="text-slate-500 text-sm mb-1">days until your exam</div>
              <div className="text-slate-400 text-xs mb-4">
                {new Date(testDateData.date).toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </div>
              <Button variant="ghost" onClick={() => { setEditingDate(true); setDateInput(testDateData.date!); }}>
                Change date
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-sm text-slate-500">Set your exam date to track your countdown.</p>
              <input
                type="date"
                value={dateInput}
                onChange={(e) => setDateInput(e.target.value)}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <div className="flex gap-2">
                <Button onClick={handleSaveDate} disabled={!dateInput}>Save</Button>
                {editingDate && (
                  <Button variant="secondary" onClick={() => setEditingDate(false)}>Cancel</Button>
                )}
              </div>
            </div>
          )}
        </Card>

        {/* Recent activity */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-slate-800">Recent Sessions</h2>
            <Link to="/metrics" className="text-xs text-blue-600 hover:underline">
              View all
            </Link>
          </div>
          {metrics?.recentSessions.length ? (
            <ul className="space-y-2">
              {metrics.recentSessions.slice(0, 4).map((s) => (
                <li
                  key={s.sessionId}
                  className="flex items-center justify-between text-sm py-1 border-b border-slate-100 last:border-0"
                >
                  <div>
                    <div className="font-medium text-slate-700 truncate max-w-[200px]">{s.caseTitle}</div>
                    <div className="text-xs text-slate-400">{s.category}</div>
                  </div>
                  <span
                    className={`font-bold text-sm ${
                      s.score >= 75
                        ? "text-green-600"
                        : s.score >= 50
                        ? "text-yellow-600"
                        : "text-red-600"
                    }`}
                  >
                    {s.score}%
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-400 py-6 text-center">
              No sessions yet — start a case to see your history here.
            </p>
          )}
        </Card>
      </div>

      {/* How it works */}
      <Card className="p-6">
        <h2 className="font-semibold text-slate-800 mb-4">How It Works</h2>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {[
            { step: "1", title: "Pick a Case", desc: "Choose from real-world optometry clinical scenarios." },
            { step: "2", title: "Interview & Examine", desc: "Ask the patient questions and order relevant tests." },
            { step: "3", title: "Write A&P", desc: "Submit your assessment and management plan." },
            { step: "4", title: "Get Feedback", desc: "Receive a score and detailed learning points." },
          ].map((s) => (
            <div key={s.step} className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-sm flex items-center justify-center">
                {s.step}
              </div>
              <div>
                <div className="font-medium text-sm text-slate-800">{s.title}</div>
                <div className="text-xs text-slate-500 mt-0.5">{s.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <Card className="p-4 flex items-center gap-4">
      <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center">{icon}</div>
      <div>
        <div className="text-2xl font-bold text-slate-800">{value}</div>
        <div className="text-xs text-slate-500">{label}</div>
      </div>
    </Card>
  );
}
