import { BarChart2, TrendingUp, Award, BookOpen } from "lucide-react";
import { useGetMetrics } from "../api/client";
import { Card, ScoreRing, Spinner, EmptyState } from "../components/ui";
import { Link } from "react-router-dom";

export default function Metrics() {
  const { data: metrics, isLoading } = useGetMetrics();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Spinner className="w-8 h-8" />
      </div>
    );
  }

  if (!metrics || metrics.totalSessionsCompleted === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Performance Metrics</h1>
          <p className="text-slate-500 text-sm mt-1">Track your progress across all cases.</p>
        </div>
        <EmptyState
          icon={<BarChart2 className="w-16 h-16" />}
          title="No data yet"
          description="Complete your first case to see your metrics here."
        />
        <div className="flex justify-center">
          <Link
            to="/exam"
            className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors"
          >
            <BookOpen className="w-4 h-4" /> Start a Case
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Performance Metrics</h1>
        <p className="text-slate-500 text-sm mt-1">Track your progress across all cases.</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-800">{metrics.totalSessionsCompleted}</div>
            <div className="text-xs text-slate-500">Cases Completed</div>
          </div>
        </Card>

        <Card className="p-5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-800">{metrics.averageScore}%</div>
            <div className="text-xs text-slate-500">Average Score</div>
          </div>
        </Card>

        <Card className="p-5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center">
            <Award className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-800">{metrics.categoryMetrics.length}</div>
            <div className="text-xs text-slate-500">Categories Practiced</div>
          </div>
        </Card>
      </div>

      {/* Category breakdown */}
      {metrics.categoryMetrics.length > 0 && (
        <Card className="p-6">
          <h2 className="font-semibold text-slate-800 mb-4">Performance by Category</h2>
          <div className="space-y-4">
            {metrics.categoryMetrics.map((cat) => (
              <div key={cat.category}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm font-medium text-slate-700">{cat.category}</span>
                  <span className="text-sm font-bold text-slate-800">{cat.avgScore}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      cat.avgScore >= 75
                        ? "bg-green-500"
                        : cat.avgScore >= 50
                        ? "bg-yellow-500"
                        : "bg-red-500"
                    }`}
                    style={{ width: `${cat.avgScore}%` }}
                  />
                </div>
                <div className="text-xs text-slate-400 mt-1">{cat.casesAttempted} case(s)</div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Recent sessions */}
      {metrics.recentSessions.length > 0 && (
        <Card className="p-6">
          <h2 className="font-semibold text-slate-800 mb-4">Recent Sessions</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-slate-400 uppercase tracking-wide border-b border-slate-100">
                  <th className="text-left pb-2 font-medium">Case</th>
                  <th className="text-left pb-2 font-medium">Category</th>
                  <th className="text-left pb-2 font-medium">Score</th>
                  <th className="text-left pb-2 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {metrics.recentSessions.map((s) => (
                  <tr key={s.sessionId} className="border-b border-slate-50 last:border-0">
                    <td className="py-2.5 font-medium text-slate-700 max-w-[200px] truncate">
                      {s.caseTitle}
                    </td>
                    <td className="py-2.5 text-slate-500">{s.category}</td>
                    <td className="py-2.5">
                      <span
                        className={`font-bold ${
                          s.score >= 75
                            ? "text-green-600"
                            : s.score >= 50
                            ? "text-yellow-600"
                            : "text-red-600"
                        }`}
                      >
                        {s.score}%
                      </span>
                    </td>
                    <td className="py-2.5 text-slate-400">
                      {new Date(s.completedAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
