import { Outlet, NavLink } from "react-router-dom";
import { Eye, BookOpen, BarChart2, Home } from "lucide-react";

export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-blue-900 text-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="w-6 h-6 text-blue-300" />
            <span className="font-bold text-lg tracking-tight">NBEO Part 3 Simulator</span>
          </div>
          <nav className="flex items-center gap-1">
            <NavItem to="/" icon={<Home className="w-4 h-4" />} label="Home" />
            <NavItem to="/exam" icon={<BookOpen className="w-4 h-4" />} label="Cases" />
            <NavItem to="/metrics" icon={<BarChart2 className="w-4 h-4" />} label="Metrics" />
          </nav>
        </div>
      </header>

      {/* Page content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8">
        <Outlet />
      </main>

      <footer className="bg-slate-100 border-t border-slate-200 text-center text-xs text-slate-400 py-3">
        NBEO Part 3 Simulator — For educational use only
      </footer>
    </div>
  );
}

function NavItem({
  to,
  icon,
  label,
}: {
  to: string;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <NavLink
      to={to}
      end
      className={({ isActive }) =>
        `flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
          isActive
            ? "bg-blue-700 text-white"
            : "text-blue-200 hover:bg-blue-800 hover:text-white"
        }`
      }
    >
      {icon}
      {label}
    </NavLink>
  );
}
