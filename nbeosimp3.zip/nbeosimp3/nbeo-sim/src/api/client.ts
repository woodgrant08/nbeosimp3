import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

const BASE = "/api";

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...init?.headers },
    ...init,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? "Request failed");
  }
  return res.json();
}

// ─── Types ───────────────────────────────────────────────────────────────────

export interface CaseSummary {
  id: number;
  title: string;
  category: string;
  difficulty: "easy" | "medium" | "hard";
  chiefComplaint: string;
  patientInfo: { age: number; sex: string; occupation: string };
}

export interface CaseDetail extends CaseSummary {
  history: string;
}

export interface Session {
  id: number;
  caseId: number;
  startedAt: string;
  completedAt?: string;
  questions: Array<{ question: string; answer: string; timestamp: string }>;
  testsOrdered: Array<{ test: string; result: string; timestamp: string }>;
  assessment?: string;
  plan?: string;
  score?: number;
  feedback?: string;
}

export interface SubmissionResult {
  sessionId: number;
  score: number;
  feedback: string;
}

export interface Metrics {
  totalSessionsCompleted: number;
  averageScore: number;
  categoryMetrics: Array<{ category: string; casesAttempted: number; avgScore: number }>;
  recentSessions: Array<{
    sessionId: number;
    caseTitle: string;
    category: string;
    score: number;
    completedAt: string;
  }>;
}

export interface TestDate {
  date: string | null;
}

// ─── Cases ───────────────────────────────────────────────────────────────────

export function useListCases(params?: { category?: string; difficulty?: string }) {
  const query = new URLSearchParams();
  if (params?.category) query.set("category", params.category);
  if (params?.difficulty) query.set("difficulty", params.difficulty);
  const qs = query.toString();
  return useQuery<CaseSummary[]>({
    queryKey: ["cases", params],
    queryFn: () => apiFetch(`/cases${qs ? `?${qs}` : ""}`),
  });
}

export function useGetCase(id: number) {
  return useQuery<CaseDetail>({
    queryKey: ["cases", id],
    queryFn: () => apiFetch(`/cases/${id}`),
    enabled: !!id,
  });
}

export function useAskPatient(caseId: number) {
  return useMutation<{ answer: string }, Error, string>({
    mutationFn: (question: string) =>
      apiFetch(`/cases/${caseId}/ask`, {
        method: "POST",
        body: JSON.stringify({ question }),
      }),
  });
}

export function useRequestTests(caseId: number) {
  return useMutation<{ results: Array<{ test: string; result: string }> }, Error, string[]>({
    mutationFn: (tests: string[]) =>
      apiFetch(`/cases/${caseId}/ancillary-tests`, {
        method: "POST",
        body: JSON.stringify({ tests }),
      }),
  });
}

// ─── Sessions ────────────────────────────────────────────────────────────────

export function useCreateSession() {
  return useMutation<Session, Error, number>({
    mutationFn: (caseId: number) =>
      apiFetch("/sessions", { method: "POST", body: JSON.stringify({ caseId }) }),
  });
}

export function useGetSession(id: number) {
  return useQuery<Session>({
    queryKey: ["sessions", id],
    queryFn: () => apiFetch(`/sessions/${id}`),
    enabled: !!id,
  });
}

export function useSubmitSession(sessionId: number) {
  const qc = useQueryClient();
  return useMutation<SubmissionResult, Error, { assessment: string; plan: string }>({
    mutationFn: (data) =>
      apiFetch(`/sessions/${sessionId}/submit`, {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sessions", sessionId] });
      qc.invalidateQueries({ queryKey: ["metrics"] });
    },
  });
}

// ─── Metrics ──────────────────────────────────────────────────────────────────

export function useGetMetrics() {
  return useQuery<Metrics>({
    queryKey: ["metrics"],
    queryFn: () => apiFetch("/metrics"),
  });
}

// ─── Test Date ────────────────────────────────────────────────────────────────

export function useGetTestDate() {
  return useQuery<TestDate>({
    queryKey: ["testDate"],
    queryFn: () => apiFetch("/test-date"),
  });
}

export function useSetTestDate() {
  const qc = useQueryClient();
  return useMutation<TestDate, Error, string | null>({
    mutationFn: (date) =>
      apiFetch("/test-date", { method: "PUT", body: JSON.stringify({ date }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["testDate"] }),
  });
}
