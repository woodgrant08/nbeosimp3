import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/home";
import Exam from "./pages/exam";
import Simulation from "./pages/simulation";
import Results from "./pages/results";
import Metrics from "./pages/metrics";
import NotFound from "./pages/not-found";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/exam" element={<Exam />} />
        <Route path="/simulation/:caseId" element={<Simulation />} />
        <Route path="/results/:sessionId" element={<Results />} />
        <Route path="/metrics" element={<Metrics />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
